require 'byebug'
class Array

  # Monkey patch the Array class and add a my_inject method. If my_inject receives
  # no argument, then use the first element of the array as the default accumulator.

  def my_inject(accumulator = nil)
    accumulator ||= accumulator = self[0]
    (1...self.length).each do |i|
      case accumulator <=> self[i]  
      when -1
        accumulator
      when 0 
        accumulator
      when 1
        self[i]
      end
      accumulator
    end 
  end
end

# primes(num) returns an array of the first "num" primes.
# You may wish to use an is_prime? helper method.

def is_prime?(num)
  return false if num < 2
  (2...num).none? { |fact| num % fact == 0 }
end

def primes(num)
  prime = []
  i = 1
  until prime.length == num
    prime << i if prime?(i)
  end
  prime
end

# Write a recursive method that returns the first "num" factorial numbers.
# Note that the 1st factorial number is 0!, which equals 1. The 2nd factorial
# is 1!, the 3rd factorial is 2!, etc.

def factorials_rec(num)
  return 1 if num == 0
  facts = []
  facts << num * factorials_rec(num - 1)
  facts
end

class Array

  # Write an Array#dups method that will return a hash containing the indices of all
  # duplicate elements. The keys are the duplicate elements; the values are
  # arrays of their indices in ascending order, e.g.
  # [1, 3, 4, 3, 0, 3, 0].dups => { 3 => [1, 3, 5], 0 => [4, 6] }

  def dups
    dup_hash = Hash.new { |h, k| h[k] = [] }
    self.each_with_index do |ele, i| 
      dup_hash[ele] << i
    end
    dup_hash
  end
end

class String

  # Write a String#symmetric_substrings method that returns an array of substrings
  # that are palindromes, e.g. "cool".symmetric_substrings => ["oo"]
  # Only include substrings of length > 1.

  def symmetric_substrings
    subs = []
    (0...self.length).each do |i|
      (i + 1...self.length).each do |i2|
        sub_s += i2
      end
    end
    subs.select { |sub| is_palindrome?(sub) }
  end

  def is_palindrome?(str)
    str == str.reverse
  end
end

class Array

  # Write an Array#merge_sort method; it should not modify the original array.

  def merge_sort(&prc)
  end

  private
  def self.merge(left, right, &prc)
  end
end
